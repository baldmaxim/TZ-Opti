const BASE = '/api';

async function request(path, { method = 'GET', body, headers, isForm } = {}) {
  const opts = { method, headers: { ...(headers || {}) } };
  if (body !== undefined) {
    if (isForm) {
      opts.body = body;
    } else {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
  }
  const res = await fetch(BASE + path, opts);
  if (!res.ok) {
    let err = 'Ошибка ' + res.status;
    try { const data = await res.json(); err = data.error || err; } catch (_e) { /* ignore */ }
    throw new Error(err);
  }
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) return res.json();
  return res.text();
}

export const api = {
  // Тендеры
  listTenders: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request('/tenders' + (q ? '?' + q : ''));
  },
  getTender: (id) => request(`/tenders/${id}`),
  createTender: (data) => request('/tenders', { method: 'POST', body: data }),
  updateTender: (id, data) => request(`/tenders/${id}`, { method: 'PATCH', body: data }),
  deleteTender: (id) => request(`/tenders/${id}`, { method: 'DELETE' }),

  // Документы
  listDocuments: (tenderId) => request(`/tenders/${tenderId}/documents`),
  uploadDocument: (tenderId, file, docType, comment = '') => {
    const fd = new FormData();
    fd.append('file', file);
    fd.append('doc_type', docType);
    if (comment) fd.append('comment', comment);
    return request(`/tenders/${tenderId}/documents`, { method: 'POST', body: fd, isForm: true });
  },
  deleteDocument: (id) => request(`/documents/${id}`, { method: 'DELETE' }),
  documentDownloadUrl: (id) => `${BASE}/documents/${id}/download`,

  // Локи разделов подготовки
  getSetupLocks: (tenderId) => request(`/tenders/${tenderId}/setup/locks`),
  lockSetup: (tenderId, section) => request(`/tenders/${tenderId}/setup/${section}/lock`, { method: 'POST' }),
  unlockSetup: (tenderId, section) => request(`/tenders/${tenderId}/setup/${section}/unlock`, { method: 'POST' }),

  // Чек-лист
  listChecklist: (tenderId) => request(`/tenders/${tenderId}/checklist`),
  createChecklist: (tenderId, data) => request(`/tenders/${tenderId}/checklist`, { method: 'POST', body: data }),
  updateChecklist: (tenderId, itemId, data) => request(`/tenders/${tenderId}/checklist/${itemId}`, { method: 'PATCH', body: data }),
  deleteChecklist: (tenderId, itemId) => request(`/tenders/${tenderId}/checklist/${itemId}`, { method: 'DELETE' }),
  resetChecklistToStandard: (tenderId) => request(`/tenders/${tenderId}/checklist/standard`, { method: 'POST' }),

  // Существенные условия — параметрический шаблон
  getSetupParams: (tenderId) => request(`/tenders/${tenderId}/setup/params`),
  updateSetupParams: (tenderId, data) => request(`/tenders/${tenderId}/setup/params`, { method: 'PUT', body: data }),
  getSetupParamsSchema: (tenderId) => request(`/tenders/${tenderId}/setup/params/schema`),

  listConditions: (tenderId) => request(`/tenders/${tenderId}/conditions`),
  patchCondition: (tenderId, idx, data) => request(`/tenders/${tenderId}/conditions/${idx}`, { method: 'PATCH', body: data }),
  removeConditionOverride: (tenderId, idx) => request(`/tenders/${tenderId}/conditions/${idx}/override`, { method: 'DELETE' }),
  resetConditions: (tenderId) => request(`/tenders/${tenderId}/conditions/reset`, { method: 'POST' }),

  // Риски — стандартная библиотека + кастомные + per-tender overlay
  listRisks: (tenderId) => request(`/tenders/${tenderId}/risks`),
  patchRiskState: (tenderId, key, data) => request(`/tenders/${tenderId}/risks/${encodeURIComponent(key)}`, { method: 'PATCH', body: data }),
  resetRisks: (tenderId) => request(`/tenders/${tenderId}/risks/reset`, { method: 'POST' }),
  getRiskMatches: (tenderId) => request(`/tenders/${tenderId}/risks/matches`),
  createCustomRisk: (tenderId, data) => request(`/tenders/${tenderId}/risks/custom`, { method: 'POST', body: data }),
  deleteCustomRisk: (tenderId, customId) => request(`/tenders/${tenderId}/risks/custom/${customId}`, { method: 'DELETE' }),

  // Q&A
  uploadQa: (tenderId, file) => {
    const fd = new FormData();
    fd.append('file', file);
    return request(`/tenders/${tenderId}/qa/import`, { method: 'POST', body: fd, isForm: true });
  },
  listQa: (tenderId) => request(`/tenders/${tenderId}/qa`),
  patchQaEntry: (tenderId, entryId, data) => request(`/tenders/${tenderId}/qa/${entryId}`, { method: 'PATCH', body: data }),
  autoLinkQa: (tenderId, opts = {}) => request(`/tenders/${tenderId}/qa/auto-link`, { method: 'POST', body: opts }),
  listCharacteristics: (tenderId) => request(`/tenders/${tenderId}/characteristics`),
  createCharacteristic: (tenderId, data) => request(`/tenders/${tenderId}/characteristics`, { method: 'POST', body: data }),
  seedCharacteristics: (tenderId) => request(`/tenders/${tenderId}/characteristics/seed`, { method: 'POST' }),
  updateCharacteristic: (id, data) => request(`/characteristics/${id}`, { method: 'PATCH', body: data }),
  deleteCharacteristic: (id) => request(`/characteristics/${id}`, { method: 'DELETE' }),

  // Стадии
  getStages: (tenderId) => request(`/tenders/${tenderId}/stages`),
  runStage: (tenderId, n) => request(`/tenders/${tenderId}/stages/${n}/run`, { method: 'POST' }),
  finishStage: (tenderId, n) => request(`/tenders/${tenderId}/stages/${n}/finish`, { method: 'POST' }),
  resetStage: (tenderId, n) => request(`/tenders/${tenderId}/stages/${n}/reset`, { method: 'POST' }),
  listStageIssues: (tenderId, n, params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/tenders/${tenderId}/stages/${n}/issues` + (q ? '?' + q : ''));
  },

  // Сигналы (debug-слой новой архитектуры анализа: signals)
  listSignals: (tenderId, signalType = null) =>
    request(`/tenders/${tenderId}/signals${signalType ? `?signal_type=${encodeURIComponent(signalType)}` : ''}`),

  // Единый анализатор ТЗ (debug-слой: draft_issues поверх signals)
  buildDraftIssues: (tenderId) => request(`/tenders/${tenderId}/unified/build`, { method: 'POST' }),
  listDraftIssues: (tenderId) => request(`/tenders/${tenderId}/draft-issues`),

  // Critic (debug-слой: оценка значимости draft_issues для генподрядчика)
  buildIssueReviews: (tenderId) => request(`/tenders/${tenderId}/critic/build`, { method: 'POST' }),
  listIssueReviews: (tenderId, mode = 'working') =>
    request(`/tenders/${tenderId}/issue-reviews?mode=${encodeURIComponent(mode)}`),

  // Clustering (debug-слой: объединение похожих замечаний по одному месту ТЗ)
  buildClusters: (tenderId) => request(`/tenders/${tenderId}/clustering/build`, { method: 'POST' }),
  listClusters: (tenderId, mode = 'working') =>
    request(`/tenders/${tenderId}/issue-clusters?mode=${encodeURIComponent(mode)}`),

  // Self-analysis (debug-слой: QC/полнота над итогом — кластеры + ТЗ, новая роль Стадии 5)
  buildSelfAnalysis: (tenderId) => request(`/tenders/${tenderId}/self-analysis/build`, { method: 'POST' }),
  listSelfAnalysis: (tenderId, findingType = null) =>
    request(`/tenders/${tenderId}/self-analysis${findingType ? `?finding_type=${encodeURIComponent(findingType)}` : ''}`),

  // Pipeline (оркестратор конвейера: draft_issues → critic → clustering → self-analysis)
  runPipeline: (tenderId, { withSelfAnalysis = true } = {}) =>
    request(`/tenders/${tenderId}/pipeline/run`, {
      method: 'POST',
      body: { with_self_analysis: withSelfAnalysis },
    }),
  getPipelineStatus: (tenderId) => request(`/tenders/${tenderId}/pipeline/status`),

  // Решения (legacy issue-level — внутри стадий 1–4)
  patchIssue: (id, data) => request(`/issues/${id}`, { method: 'PATCH', body: data }),
  decideIssue: (id, data) => request(`/issues/${id}/decision`, { method: 'POST', body: data }),

  // Cluster-review (этап 6): issue_clusters — основной объект финальной рецензии.
  buildReviewClusters: (tenderId, force = false) =>
    request(`/tenders/${tenderId}/review/clusters/build${force ? '?force=1' : ''}`, { method: 'POST' }),
  listReviewClusters: (tenderId, mode = 'working') =>
    request(`/tenders/${tenderId}/review/clusters?mode=${encodeURIComponent(mode)}`),
  getReviewCluster: (tenderId, clusterId) =>
    request(`/tenders/${tenderId}/review/clusters/${clusterId}`),
  decideCluster: (tenderId, clusterId, data) =>
    request(`/tenders/${tenderId}/review/clusters/${clusterId}/decision`, { method: 'POST', body: data }),

  // Превью + экспорт
  reviewPreviewUrl: (tenderId) => `${BASE}/tenders/${tenderId}/review/preview`,
  // Слой сборки: единый итог (группы находок + конфликты + вердикты).
  getConsolidated: (tenderId) => request(`/tenders/${tenderId}/review/consolidated`),
  exportDocxUrl: (tenderId, stage = null) =>
    `${BASE}/tenders/${tenderId}/export/docx${stage ? `?stage=${stage}` : ''}`,
  exportCsvUrl: (tenderId) => `${BASE}/tenders/${tenderId}/export/issues.csv`,
  exportJsonUrl: (tenderId) => `${BASE}/tenders/${tenderId}/export/issues.json`,
  exportSummaryUrl: (tenderId) => `${BASE}/tenders/${tenderId}/export/summary.md`,
  exportReviewMdUrl: (tenderId, stage = null) =>
    `${BASE}/tenders/${tenderId}/export/review.md${stage ? `?stage=${stage}` : ''}`,
  // Dry-run отчёт «что попало в Word, а что нет» (без скачивания файла).
  exportDocxReport: (tenderId, stage = null) =>
    request(`/tenders/${tenderId}/export/docx/report${stage ? `?stage=${stage}` : ''}`),
};

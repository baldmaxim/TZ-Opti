# devtools — локальный Claude-бридж для Стадии 1

> ⚠️ **Dev-only. Не продакшен.** Это локальный костыль для разработки/демо, а не
> часть production-архитектуры. Не коммитить как штатный путь LLM.

## Что это

`claudeBridge.js` — крошечный HTTP-сервер, который снаружи говорит на диалекте
OpenAI (`POST /v1/chat/completions`), а внутри вызывает **Claude** через
`@anthropic-ai/claude-agent-sdk`.

Стадия 1 (`server/services/stageAnalysis/stage1_llm.js`) ходит в LLM через
`llm/openaiClient.js`, которому нужен `OPENAI_API_KEY`. Ключа OpenAI нет. Бридж
закрывает эту дыру **без единого API-ключа** — он переиспользует авторизацию
**подписки Claude Code** пользователя (SDK сам берёт креды из `~/.claude`).
`ANTHROPIC_API_KEY` намеренно стирается на старте, чтобы не уйти на платный API.

```
Стадия 1 → openaiClient (OPENAI_BASE_URL) → claudeBridge :4010
         → Agent SDK query() → Claude Sonnet 4.6 (подписка Claude Code)
```

Существующий серверный код **не меняется**: `isConfigured()` в `openaiClient.js`
проверяет лишь непустоту `OPENAI_API_KEY`, поэтому фиктивного значения хватает,
а `OPENAI_BASE_URL` уводит все вызовы Стадии 1 на бридж.

## Включение (`.env` в корне репозитория)

```
OPENAI_BASE_URL=http://127.0.0.1:4010/v1
OPENAI_API_KEY=local-claude-bridge   # фиктивный — проходит гард, в Claude не уходит
BRIDGE_MODEL=claude-sonnet-4-6
BRIDGE_PORT=4010
BRIDGE_TIMEOUT_MS=900000   # ~8 мин/прогон вариативно → 15 мин с запасом
```

Стадия 1 защищена гардом одновременности (`stageAnalysisEngine.js`,
`RUNNING_STAGES`): второй запуск той же стадии того же тендера, пока идёт
первый, отклоняется с понятной ошибкой. Это намеренно — подписка не держит
параллель, одновременные прогоны душат друг друга и ловят таймаут.
Цепочка таймаутов согласована: бридж 900000 < openai-клиент 1020000 <
server.requestTimeout 1140000 (server/app.js) < Vite proxy 1140000
(client/vite.config.js).

Доп. тюнинг Стадии 1 (опционально, есть разумные дефолты в коде):
`STAGE1_CHAR_BUDGET` (400000 — размер сегмента),
`STAGE1_CONCURRENCY` (1 — одновременных вызовов. ПРОВЕРЕНО: подписка Claude
Code НЕ держит параллель — конкурентные вызовы троттлятся и ловят таймаут,
мелкие последовательные тоже медленнее. Поэтому дефолт = 1 (один большой
сегмент, ~6-7 мин — самый надёжный путь). >1 имеет смысл только на платном
прямом API),
`STAGE1_VOR_MAX_CHARS` (90000 — если компакт-ВОР больше, авто-уход в запасной
режим «только чек-лист» с пометкой в summary),
`STAGE1_PROMPT_VARIANT` (`structural` дефолт | `strict` | `full` — режим
системного промта агента; см. server/services/stageAnalysis/stage1Prompts.js),
`STAGE1_FAST_THINKING` (по умолчанию ВЫКЛ; `1`/`true` отключает extended
thinking — быстрее, но включать только после A/B-сравнения качества с
эталоном, иначе возможна потеря качества).

Режим промта остальных стадий (значения те же: `structural` дефолт | `strict`
| `full`): `STAGE2_PROMPT_VARIANT` (Стадия 2 — Q&A + характеристики; см.
server/services/stageAnalysis/stage2Prompts.js) и `STAGE3_PROMPT_VARIANT`
(Стадия 3 — существенные условия компании, режим «только противоречия»: агент
выносит лишь места ТЗ, противоречащие условиям компании; см.
server/services/stageAnalysis/stage3Prompts.js) и `STAGE4_PROMPT_VARIANT`
(Стадия 4 — типовые риски: прямые/косвенные упоминания рисков, влекущих доп.
неоплачиваемые работы / финансовые потери ГП; см.
server/services/stageAnalysis/stage4Prompts.js) и `STAGE5_PROMPT_VARIANT`
(Стадия 5 — самоанализ ТЗ: скрытые работы, двусмысленные формулировки, влияние
на срок; см. server/services/stageAnalysis/stage5Prompts.js).

`OPENAI_MODEL` НЕ задавать — бридж игнорирует поле `model` из запроса и всегда
использует `BRIDGE_MODEL`.

## Запуск

`npm run dev` (в корне) теперь поднимает три процесса: `server`, `client`,
`bridge`. Бридж стартует обычным `node` (не nodemon), чтобы переживать рестарты
Express во время долгого вызова Claude.

Отдельно: `npm run bridge`. Проверка: `GET http://127.0.0.1:4010/health`.

## Структурированный вывод

Claude не поддерживает OpenAI `strict` json_schema. Бридж: схема в промпт →
извлечение JSON (срез ```` ``` ````-заборов + баланс-скан) → валидация `ajv`
против переданной схемы → **один** repair-retry. Если и после ретрая ответ
невалиден по схеме, но синтаксически JSON — отдаётся best-effort: downstream
`fragmentMatcher` в `stage1_llm.js` всё равно отбрасывает находки без дословного
совпадения фрагмента.

Перед передачей схемы в нативный `outputFormat` SDK она прогоняется через
`sanitizeSchemaForStructuredOutput` — union-типы вида `type:['string','null']`
схлопываются в первый не-null примитив (иначе харнесс игнорирует `outputFormat`
и возвращает прозу). `ajv` при этом валидирует против **оригинальной** строгой
схемы.

Порядок попыток: `outputFormat` (санитайзенная схема) → `repair` (схема в
промпте + причина) → `noOutputFormat` (без structured-output-машинерии SDK,
чистый JSON в промпте). Если **все** три без JSON — бридж отдаёт 400 с понятным
сообщением «ИИ не смог проанализировать ТЗ… Нажмите „Запустить“ ещё раз»
(fail-loud, без тихой деградации в пустой результат).

## Диагностика

Каждый запрос пишет полный дамп в `server/devtools/.debug/`
(`bridge-<ISO>-<reqId>.json`, под `.gitignore`, dev-only): размеры промпта,
результат компиляции схемы `ajv`, и по каждой попытке — `subtype`, наличие
`structured_output`, `num_turns`, `errors` и **полный необрезанный** сырой ответ
Claude. Держатся последние 50 дампов (старые автоудаляются). Туда же указывает
путь в сообщении об ошибке. Это первый артефакт для разбора «ИИ не смог…».

## ⚠️ Безопасность временного Cloudflare-туннеля

`cloudflared tunnel --url http://localhost:5173` даёт **публичный** URL. CORS на
сервере открыт (`app.use(cors())`), API ходит к **реальной БД на чтение И
запись**. Любой со ссылкой может создавать/удалять тендеры и менять данные.

- Туннель — короткоживущий: поднять перед демо, Ctrl-C сразу после.
- Не публиковать URL в каналах, переживающих сессию.
- Для не-соло-использования — `cloudflared access` (Zero Trust, одноразовый PIN)
  или Basic Auth.

## Полный откат

```
git checkout client/vite.config.js
# удалить строки OPENAI_*/BRIDGE_* из корневого .env
# убрать "bridge" из package.json (скрипт + 3-й процесс в dev)
rm -r server/devtools
# Ctrl-C терминалов бриджа и cloudflared
```

Обычный `npm run dev` на localhost при невыставленном `TUNNEL` и отсутствии
`OPENAI_*` остаётся нетронутым.

'use strict';

const db = require('../../db/connection');
const { newId, nowIso } = require('../../utils/ids');
const { badRequest } = require('../../utils/errors');
const { getActiveTzText, getDocumentByType } = require('../tzActiveTextService');
const { runStage1Llm } = require('./stage1_llm');
const { runStage2Llm } = require('./stage2_llm');
const { runStage3Llm } = require('./stage3_llm');
const { runStage4Llm } = require('./stage4_llm');
const selfAnalysis = require('../selfAnalysis/selfAnalysisService');
const { importQaXlsx } = require('../qaImportService');
const { isConfigured: isOpenAiConfigured } = require('./llm/openaiClient');
const { isOwnedBy, stageResultType } = require('../review/stageDomains');
const { writeSignalsForStage } = require('../signals/signalWriter');
const progressRegistry = require('./progressRegistry');

// Единый серверный источник названий стадий (идёт в summary.label).
// Тексты должны совпадать с STAGE_META на клиенте (client/src/utils/labels.js).
const STAGE_LABELS = {
  1: 'ТЗ + Чек-лист + ВОР',
  2: 'Q&A + Характеристики',
  3: 'Существенные условия компании',
  4: 'Типовые риски',
  5: 'Самоанализ ТЗ',
};

async function getStageState(tenderId) {
  let state = await db.queryOne('SELECT * FROM tender_stage_state WHERE tender_id = ?', tenderId);
  if (!state) {
    await db.queryRun(
      `
      INSERT INTO tender_stage_state (tender_id, current_stage, stage1_status, stage2_status, stage3_status, stage4_status, stage5_status)
      VALUES (?, 1, 'open', 'locked', 'locked', 'locked', 'locked')
    `,
      tenderId,
    );
    state = await db.queryOne('SELECT * FROM tender_stage_state WHERE tender_id = ?', tenderId);
  }
  return state;
}

function isStageRunnable(state, stage) {
  if (stage === 1) return ['open', 'running', 'reviewing'].includes(state.stage1_status);
  const prevKey = `stage${stage - 1}_status`;
  if (state[prevKey] !== 'finished') return false;
  const cur = state[`stage${stage}_status`];
  return cur !== 'finished';
}

async function setStageStatus(tenderId, stage, status, runner = db) {
  const col = `stage${stage}_status`;
  await runner.queryRun(
    `UPDATE tender_stage_state SET ${col} = ?, current_stage = ? WHERE tender_id = ?`,
    status,
    stage,
    tenderId,
  );
}

async function unlockNextStage(tenderId, stage, runner = db) {
  if (stage >= 5) return;
  const nextCol = `stage${stage + 1}_status`;
  await runner.queryRun(
    `UPDATE tender_stage_state SET ${nextCol} = 'open', current_stage = ? WHERE tender_id = ?`,
    stage + 1,
    tenderId,
  );
}

async function buildContextForStage(tenderId, stage) {
  const { document: tzDoc, paragraphs, blocks, activeText, rawText, missingMd } = await getActiveTzText(tenderId, stage);
  if (missingMd || !tzDoc) {
    throw badRequest('Загрузите .md-копию ТЗ в слот «ТЗ → Markdown» — анализ ведётся только по .md.');
  }
  const ctx = {
    tenderId,
    sourceDocumentId: tzDoc.id,
    paragraphs,
    blocks,
    activeText,
    rawText,
    rawMd: rawText,
  };
  if (stage === 1) {
    const vorDoc = await getDocumentByType(tenderId, 'vor');
    ctx.vorText = vorDoc ? (vorDoc.extracted_text || '') : '';
    ctx.checklist = await db.queryAll('SELECT * FROM work_checklist_items WHERE tender_id = ?', tenderId);
  }
  if (stage === 2) {
    ctx.qaEntries = await db.queryAll('SELECT * FROM qa_entries WHERE tender_id = ? ORDER BY order_idx ASC', tenderId);
    // Таблица характеристик — второй справочник принятого (значения, принятые
    // компанией в расчёт). Стадия 2 сверяет ТЗ и с Q&A-решениями, и с ней.
    ctx.characteristics = await db.queryAll(
      'SELECT * FROM characteristics WHERE tender_id = ? ORDER BY sort_order ASC, name ASC',
      tenderId,
    );
  }
  // Стадия 3 (Существенные условия) и Стадия 4 (Типовые риски) сами загружают
  // нужные данные из БД (company_conditions / risks_state) — отдельный
  // ctx-prefetch не требуется.
  return ctx;
}

// Стадия 5 — НОВАЯ роль: self-analysis как quality-control над ИТОГОМ
// (кластеры новой архитектуры + исходный ТЗ), а НЕ второй поток issues по тексту.
// Поэтому она НЕ пишет в таблицу issues — возвращает пустой issues[], а находки
// о качестве разбора кладёт в self_analysis_results (selfAnalysisService).
async function runStage5SelfAnalysis(ctx) {
  const res = await selfAnalysis.buildSelfAnalysis(ctx.tenderId);
  const issues = [];
  issues.analysisNote =
    `Самоанализ (QC) над итогом: ${res.summary.findings} замечаний о качестве разбора ` +
    `по ${res.summary.clusters} кластерам — см. self_analysis_results (issues не порождаются).`;
  issues.selfAnalysis = res.summary;
  return issues;
}

function runStageOrchestrator(stage, ctx) {
  switch (stage) {
    case 1: return runStage1Llm(ctx);
    case 2: return runStage2Llm(ctx);
    case 3: return runStage3Llm(ctx);
    case 4: return runStage4Llm(ctx);
    case 5: return runStage5SelfAnalysis(ctx);
    default: throw badRequest('Допустимы стадии 1..5');
  }
}

// Подписка Claude Code НЕ держит параллель: одновременные прогоны Стадии 1
// душат друг друга и ловят таймаут (см. project_stage1_context_limit).
// Гард: один прогон на (tender,stage) за раз — второй клик/запрос получает
// понятную ошибку, а не сабботирует идущий анализ.
const RUNNING_STAGES = new Set();

async function runStage(tenderId, stage) {
  const key = `${tenderId}:${stage}`;
  if (RUNNING_STAGES.has(key)) {
    throw badRequest(
      `Анализ стадии ${stage} уже выполняется. Дождитесь завершения ` +
        `(Стадия 1 — до ~15 минут) и не запускайте повторно: параллельные ` +
        `прогоны мешают друг другу и приводят к таймауту.`,
    );
  }
  RUNNING_STAGES.add(key);
  try {
    return await runStageInner(tenderId, stage);
  } finally {
    RUNNING_STAGES.delete(key);
  }
}

// Падение фонового прогона: фиксируем failed-run (его увидит опрос статуса
// клиентом) и возвращаем статус стадии в исходное (re-runnable). Никогда не
// бросаем — это финализатор фоновой задачи.
async function recordFailedRun(tenderId, stage, prevStatus, err) {
  const msg = (err && err.message) || 'неизвестная ошибка анализа';
  try {
    await db.queryRun(
      `INSERT INTO analysis_runs (id, tender_id, stage, started_at, finished_at, status, summary)
       VALUES (?, ?, ?, ?, ?, 'failed', ?)`,
      newId(),
      tenderId,
      stage,
      nowIso(),
      nowIso(),
      JSON.stringify({ stage, label: STAGE_LABELS[stage], failed: true, error: msg }),
    );
    await setStageStatus(tenderId, stage, prevStatus);
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error(`[stageEngine] recordFailedRun сбой: ${e.message}`);
  }
}

// Фоновый запуск: быстрые проверки синхронно (гард/доступность → понятная
// 400 сразу), затем стадия считается В ФОНЕ сколько нужно. Клиент опрашивает
// статус (state.stageN_status) и узнаёт исход по последнему analysis_run.
// Это снимает «Failed to fetch»/таймаут: нет висящего HTTP-запроса.
async function startStageBackground(tenderId, stage) {
  const key = `${tenderId}:${stage}`;
  if (RUNNING_STAGES.has(key)) {
    throw badRequest(
      `Анализ стадии ${stage} уже выполняется. Дождитесь завершения — ` +
        `портал сам покажет результат (вкладку можно закрыть).`,
    );
  }
  const state = await getStageState(tenderId);
  if (stage < 1 || stage > 5) throw badRequest('Допустимы стадии 1..5');
  if (!isStageRunnable(state, stage)) {
    throw badRequest(`Стадия ${stage} недоступна. Сначала завершите стадию ${stage - 1}.`);
  }
  const prevStatus = state[`stage${stage}_status`];
  RUNNING_STAGES.add(key);
  await setStageStatus(tenderId, stage, 'running');
  progressRegistry.init(tenderId, stage); // прогресс по сегментам для круговой шкалы
  // Не ждём: ответ уходит сразу, анализ идёт в фоне.
  (async () => {
    try {
      await runStageInner(tenderId, stage);
    } catch (e) {
      await recordFailedRun(tenderId, stage, prevStatus, e);
    } finally {
      RUNNING_STAGES.delete(key);
      progressRegistry.clear(tenderId, stage);
    }
  })();
  return { status: 'running' };
}

async function runStageInner(tenderId, stage) {
  const state = await getStageState(tenderId);
  if (stage < 1 || stage > 5) throw badRequest('Допустимы стадии 1..5');
  if (!isStageRunnable(state, stage)) {
    throw badRequest(`Стадия ${stage} недоступна. Сначала завершите стадию ${stage - 1}.`);
  }
  // Все стадии 1–5 — LLM-агенты, требуют настроенного ключа.
  if (!isOpenAiConfigured()) {
    throw badRequest(`OPENAI_API_KEY не настроен на сервере. Стадия ${stage} (LLM-агент) недоступна.`);
  }
  if (stage === 2) {
    const qaCountRow = await db.queryOne('SELECT COUNT(*) as c FROM qa_entries WHERE tender_id = ?', tenderId);
    let qaCount = Number(qaCountRow?.c || 0);
    if (!qaCount) {
      // qa_entries пуст — пробуем авто-импортировать из загруженного на вкладке
      // «Документация» Q&A-файла. Это типичный кейс: пользователь залил .xlsx,
      // но импорт по какой-то причине не отработал.
      const qaDoc = await db.queryOne(
        `SELECT * FROM documents
         WHERE tender_id = ? AND doc_type = 'qa'
         ORDER BY uploaded_at DESC LIMIT 1`,
        tenderId,
      );
      if (qaDoc?.file_path) {
        try {
          await importQaXlsx(tenderId, qaDoc.file_path);
          const recheck = await db.queryOne(
            'SELECT COUNT(*) as c FROM qa_entries WHERE tender_id = ?',
            tenderId,
          );
          qaCount = Number(recheck?.c || 0);
        } catch (e) {
          // ignore — попадаем в ошибку ниже с исходным текстом
        }
      }
    }
    if (!qaCount) {
      throw badRequest('Загрузите Q&A форму (.xlsx) на вкладке «Документация» — без переписки стадия 2 не запускается.');
    }
  }

  const ctx = await buildContextForStage(tenderId, stage);
  // Репортер прогресса по сегментам — runLlmStage зовёт setTotal/tick (см. llmStage).
  ctx.progress = {
    setTotal: (n) => progressRegistry.setTotal(tenderId, stage, n),
    tick: () => progressRegistry.tick(tenderId, stage),
  };
  const issues = await runStageOrchestrator(stage, ctx);

  // Гард зоны ответственности: стадия должна писать только в свой домен
  // (см. stageDomains). Backstop против регрессий — не теряем данные, но логируем.
  const offDomain = issues.filter((i) => i.problem_type && !isOwnedBy(stage, i.problem_type));
  if (offDomain.length) {
    // eslint-disable-next-line no-console
    console.warn(
      `[stageEngine] стадия ${stage}: ${offDomain.length} находок с чужим problem_type ` +
        `(${[...new Set(offDomain.map((i) => i.problem_type))].join(', ')}) — вне домена стадии.`,
    );
  }

  const runId = newId();
  const startedAt = nowIso();
  const summary = {
    stage,
    label: STAGE_LABELS[stage],
    result_type: stageResultType(stage),
    issues_count: issues.length,
    off_domain: offDomain.length,
    by_criticality: countBy(issues, 'criticality'),
    by_problem_type: countBy(issues, 'problem_type'),
    notes: issues.analysisNote || null,
    // Стадия 5 (QC) issues не порождает — несёт сводку self-analysis вместо них.
    self_analysis: issues.selfAnalysis || null,
  };

  // Связка issue.id ↔ находка — нужна слою signals (source_entity_id ниже).
  const issueRecords = [];

  await db.transaction(async (tx) => {
    // Удаляем существующие незавершённые Issue этой стадии (повторный запуск)
    await tx.queryRun(
      `DELETE FROM issues WHERE tender_id = ? AND analysis_stage = ? AND review_status = 'pending'`,
      tenderId,
      stage,
    );

    await tx.queryRun(
      `
      INSERT INTO analysis_runs (id, tender_id, stage, started_at, finished_at, status, summary)
      VALUES (?, ?, ?, ?, ?, 'completed', ?)
    `,
      runId,
      tenderId,
      stage,
      startedAt,
      nowIso(),
      JSON.stringify(summary),
    );

    for (const issue of issues) {
      const issueId = newId();
      await tx.queryRun(
        `
        INSERT INTO issues (
          id, tender_id, analysis_run_id, analysis_stage, source_document_id, source_clause,
          source_fragment, paragraph_index, char_start, char_end,
          problem_type, risk_category, criticality, price_impact, schedule_impact,
          basis, suggested_action, suggested_redaction, review_comment, confidence,
          section_path, review_status, selected_for_export
        ) VALUES (
          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 1
        )
      `,
        issueId,
        tenderId,
        runId,
        stage,
        issue.source_document_id || null,
        issue.source_clause || null,
        issue.source_fragment || null,
        issue.paragraph_index ?? null,
        issue.char_start ?? null,
        issue.char_end ?? null,
        issue.problem_type || null,
        issue.risk_category || null,
        issue.criticality || 'medium',
        issue.price_impact || null,
        issue.schedule_impact || null,
        issue.basis || null,
        issue.suggested_action || 'comment',
        issue.suggested_redaction || null,
        issue.review_comment || null,
        issue.confidence ?? 0.6,
        issue.section_path || null,
      );
      issueRecords.push({ issueId, issue });
    }

    await setStageStatus(tenderId, stage, 'reviewing', tx);
  });

  // Параллельная запись слоя signals (новая архитектура анализа ТЗ).
  // Изолирована: best-effort writer со своей транзакцией и перехватом ошибок —
  // сбой signals НЕ влияет на уже закоммиченные issues и статус стадии.
  await writeSignalsForStage({ tenderId, runId, stage, records: issueRecords });

  return { runId, summary };
}

async function finishStage(tenderId, stage) {
  const state = await getStageState(tenderId);
  const cur = state[`stage${stage}_status`];
  if (cur === 'locked') throw badRequest('Стадия залочена');
  if (cur === 'finished') throw badRequest('Стадия уже завершена');
  // Применяем tz_excluded_ranges для решений delete / remove_from_scope
  const closeIssues = await db.queryAll(
    `
      SELECT i.*, d.decision, d.target_text FROM issues i
      LEFT JOIN review_decisions d ON d.issue_id = i.id
      WHERE i.tender_id = ? AND i.analysis_stage = ?
    `,
    tenderId,
    stage,
  );

  await db.transaction(async (tx) => {
    for (const issue of closeIssues) {
      const isDelete = issue.review_status === 'accepted'
        && (issue.decision === 'delete' || issue.decision === 'remove_from_scope');
      if (isDelete && issue.paragraph_index != null && issue.char_start != null && issue.char_end != null) {
        // Если инженер удалил только ПОДЧАСТЬ фрагмента — исключаем из активного
        // текста (для следующих стадий) ровно её, а не весь пункт.
        let cStart = issue.char_start;
        let cEnd = issue.char_end;
        const part = (issue.target_text || '').trim();
        if (part && issue.source_fragment) {
          const i = issue.source_fragment.indexOf(part);
          if (i !== -1) { cStart = issue.char_start + i; cEnd = cStart + part.length; }
        }
        await tx.queryRun(
          `
          INSERT INTO tz_excluded_ranges (id, tender_id, source_document_id, paragraph_index, char_start, char_end, after_stage, source_issue_id, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
          newId(),
          tenderId,
          issue.source_document_id || null,
          issue.paragraph_index,
          cStart,
          cEnd,
          stage,
          issue.id,
          nowIso(),
        );
      }
    }
    await setStageStatus(tenderId, stage, 'finished', tx);
    await unlockNextStage(tenderId, stage, tx);
  });
  return getStageState(tenderId);
}

async function resetStage(tenderId, stage) {
  // Каскадно сбрасываем стадии ≥ N
  await db.transaction(async (tx) => {
    const issuesToDelete = await tx.queryAll(
      'SELECT id FROM issues WHERE tender_id = ? AND analysis_stage >= ?',
      tenderId,
      stage,
    );
    const ids = issuesToDelete.map((r) => r.id);
    if (ids.length) {
      const placeholders = ids.map(() => '?').join(',');
      await tx.queryRun(`DELETE FROM review_decisions WHERE issue_id IN (${placeholders})`, ...ids);
      await tx.queryRun(`DELETE FROM tz_excluded_ranges WHERE source_issue_id IN (${placeholders})`, ...ids);
      await tx.queryRun(`DELETE FROM issues WHERE id IN (${placeholders})`, ...ids);
    }
    await tx.queryRun('DELETE FROM analysis_runs WHERE tender_id = ? AND stage >= ?', tenderId, stage);
    await tx.queryRun('DELETE FROM tz_excluded_ranges WHERE tender_id = ? AND after_stage >= ?', tenderId, stage);

    // Возвращаем статусы
    for (let s = stage; s <= 5; s += 1) {
      const status = s === stage ? 'open' : 'locked';
      await tx.queryRun(`UPDATE tender_stage_state SET stage${s}_status = ? WHERE tender_id = ?`, status, tenderId);
    }
    await tx.queryRun('UPDATE tender_stage_state SET current_stage = ? WHERE tender_id = ?', stage, tenderId);
  });
  return getStageState(tenderId);
}

async function listStageIssues(tenderId, stage, filters = {}) {
  let sql = `
    SELECT i.*, d.decision as decision_kind, d.final_comment as decision_comment, d.edited_redaction as decision_redaction, d.target_text as decision_target_text
    FROM issues i
    LEFT JOIN review_decisions d ON d.issue_id = i.id
    WHERE i.tender_id = ? AND i.analysis_stage = ?
  `;
  const params = [tenderId, stage];
  if (filters.criticality) { sql += ' AND i.criticality = ?'; params.push(filters.criticality); }
  if (filters.review_status) { sql += ' AND i.review_status = ?'; params.push(filters.review_status); }
  if (filters.problem_type) { sql += ' AND i.problem_type = ?'; params.push(filters.problem_type); }
  sql += ' ORDER BY i.criticality DESC, i.paragraph_index ASC, i.char_start ASC';
  return db.queryAll(sql, ...params);
}

async function getStageRunSummary(tenderId, stage) {
  const run = await db.queryOne(
    'SELECT * FROM analysis_runs WHERE tender_id = ? AND stage = ? ORDER BY started_at DESC LIMIT 1',
    tenderId,
    stage,
  );
  if (!run) return null;
  let summary = null;
  try { summary = run.summary ? JSON.parse(run.summary) : null; } catch (_e) { summary = null; }
  return { ...run, summary };
}

function countBy(arr, key) {
  const out = {};
  for (const i of arr) {
    const v = i[key] || '—';
    out[v] = (out[v] || 0) + 1;
  }
  return out;
}

// Авто-починка «зомби»-статусов на старте сервера. Фоновый прогон живёт в памяти
// процесса (RUNNING_STAGES + progressRegistry); при рестарте/падении сервера он
// гибнет, но в БД stageN_status мог остаться 'running' — тогда клиент бесконечно
// крутит кольцо прогресса. На старте живых прогонов ещё нет, поэтому любой
// 'running' — осиротевший: сбрасываем в 'open' (предыдущая стадия была завершена,
// иначе запуск был бы невозможен). Issue не трогаем: успешный прогон пишет их
// только в финальной транзакции, а следующий запуск всё равно чистит pending.
async function recoverOrphanedRunningStages() {
  let recovered = 0;
  for (let s = 1; s <= 5; s += 1) {
    const res = await db.queryRun(
      `UPDATE tender_stage_state SET stage${s}_status = 'open' WHERE stage${s}_status = 'running'`,
    );
    recovered += (res && (res.changes ?? res.rowCount)) || 0;
  }
  if (recovered) {
    // eslint-disable-next-line no-console
    console.log(`[stageEngine] восстановлено осиротевших 'running'-стадий: ${recovered} → 'open'`);
  }
  return recovered;
}

module.exports = {
  STAGE_LABELS,
  getStageState,
  runStage,
  startStageBackground,
  finishStage,
  resetStage,
  listStageIssues,
  getStageRunSummary,
  recoverOrphanedRunningStages,
};

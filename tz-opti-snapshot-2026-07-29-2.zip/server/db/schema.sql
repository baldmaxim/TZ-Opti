-- TZ-Opti: схема БД (PostgreSQL / Supabase; применяется через db/migrate.js)
-- ID = UUID v4 (TEXT). Даты — ISO 8601 (TEXT).

CREATE TABLE IF NOT EXISTS tenders (
  id           TEXT PRIMARY KEY,
  title        TEXT NOT NULL,
  customer     TEXT,
  type         TEXT,            -- 'general_contract' | 'shell' | 'monolith' | 'masonry' | 'waterproofing' | 'other'
  stage        TEXT,            -- стадия проекта (П / РД и т.п.)
  deadline     TEXT,
  owner        TEXT,
  status       TEXT DEFAULT 'draft',  -- 'draft' | 'in_progress' | 'submitted' | 'won' | 'lost' | 'archived'
  description  TEXT,
  created_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS documents (
  id                  TEXT PRIMARY KEY,
  tender_id           TEXT NOT NULL,
  doc_type            TEXT NOT NULL,    -- 'tz' | 'pd_rd' | 'vor' | 'checklist' | 'company_conditions' | 'risks' | 'qa' | 'other'
  name                TEXT NOT NULL,
  file_path           TEXT NOT NULL,
  mime_type           TEXT,
  version             TEXT DEFAULT '1',
  uploaded_at         TEXT NOT NULL,
  comment             TEXT,
  extracted_text      TEXT,
  processing_status   TEXT DEFAULT 'pending', -- 'pending' | 'extracted' | 'failed'
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_documents_tender ON documents(tender_id);

CREATE TABLE IF NOT EXISTS work_checklist_items (
  id                TEXT PRIMARY KEY,
  tender_id         TEXT NOT NULL,
  section           TEXT,
  work_name         TEXT NOT NULL,
  in_tz             INTEGER DEFAULT 0,
  in_pd_rd          INTEGER DEFAULT 0,
  in_vor            INTEGER DEFAULT 0,
  in_calc           INTEGER DEFAULT 0,
  in_kp             INTEGER DEFAULT 0,
  in_contract       INTEGER DEFAULT 0,
  affects_schedule  INTEGER DEFAULT 0,
  decision          TEXT,
  comment           TEXT,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_checklist_tender ON work_checklist_items(tender_id);

-- Позиции ВОР (ведомость объёмов работ), импортированные СТРУКТУРНО из xls/xlsx
-- (services/vor/). Раньше ВОР жил только как extracted_text (CSV всего листа),
-- и стадия 1 угадывала наименование по «самой длинной ячейке строки» — номер
-- позиции, шифр, единица, количество и координаты терялись.
-- Здесь одна строка = одна позиция ведомости со всеми координатами: лист,
-- номер строки Excel и адреса ячеек каждого поля (cells) — находку всегда
-- можно показать инженеру «где именно в ВОР».
CREATE TABLE IF NOT EXISTS vor_items (
  id            TEXT PRIMARY KEY,
  tender_id     TEXT NOT NULL,
  document_id   TEXT,               -- документ-источник (documents.id)
  order_idx     INTEGER NOT NULL,   -- сквозной порядок по всей книге
  sheet_name    TEXT,
  sheet_index   INTEGER,
  row_index     INTEGER,            -- 1-based строка Excel
  position_no   TEXT,               -- № п/п («12», «3.4.1»)
  code          TEXT,               -- шифр расценки / обоснование
  section       TEXT,               -- раздел (колонка или строка-заголовок выше)
  name          TEXT NOT NULL,      -- наименование работы
  name_key      TEXT,               -- нормализованный ключ (дедуп/сопоставление)
  unit          TEXT,               -- нормализованная единица (м2, м3, шт, ...)
  unit_raw      TEXT,               -- как было в файле («кв.м.»)
  unit_known    INTEGER DEFAULT 0,  -- 1 = единица распознана словарём
  quantity      DOUBLE PRECISION,   -- нормализованное количество (NULL, если не число)
  quantity_raw  TEXT,               -- как было в файле («1 234,56»)
  note          TEXT,
  row_kind      TEXT DEFAULT 'item',-- 'item' (позиция); разделы/итоги не сохраняем
  cells         TEXT,               -- JSON {поле: 'C12'} — адреса ячеек
  merged_cells  TEXT,               -- JSON {поле: 'C10'} — источник объединённой ячейки
  imported_at   TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_vor_items_tender ON vor_items(tender_id, order_idx);
CREATE INDEX IF NOT EXISTS idx_vor_items_key ON vor_items(tender_id, name_key);

CREATE TABLE IF NOT EXISTS company_conditions (
  id           TEXT PRIMARY KEY,
  tender_id    TEXT NOT NULL,
  category     TEXT,
  condition    TEXT NOT NULL,
  criticality  TEXT DEFAULT 'medium',  -- 'low' | 'medium' | 'high' | 'critical'
  comment      TEXT,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_conditions_tender ON company_conditions(tender_id);

CREATE TABLE IF NOT EXISTS risk_templates (
  id              TEXT PRIMARY KEY,
  tender_id       TEXT,             -- NULL для глобальных
  category        TEXT,
  risk_text       TEXT NOT NULL,
  recommendation  TEXT,
  criticality     TEXT DEFAULT 'medium',
  is_global       INTEGER DEFAULT 0,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_risks_tender ON risk_templates(tender_id);

CREATE TABLE IF NOT EXISTS qa_entries (
  id                 TEXT PRIMARY KEY,
  tender_id          TEXT NOT NULL,
  source_file_path   TEXT,
  section            TEXT,
  sent_at            TEXT,
  answer_at          TEXT,
  round_label        TEXT,
  tz_clause          TEXT,                 -- ссылка/название пункта ТЗ
  tz_reflected       INTEGER DEFAULT 0,    -- 0/1: решение отражено в ТЗ
  tz_contradicts     INTEGER DEFAULT 0,    -- 0/1: ТЗ противоречит решению
  affects_calc       INTEGER DEFAULT 0,    -- влияет на расчёт
  affects_kp         INTEGER DEFAULT 0,    -- влияет на КП
  affects_contract   INTEGER DEFAULT 0,    -- влияет на договор
  affects_schedule   INTEGER DEFAULT 0,    -- влияет на график
  question           TEXT,
  answer             TEXT,
  accepted_decision  TEXT,
  order_idx          INTEGER DEFAULT 0,
  imported_at        TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_qa_tender ON qa_entries(tender_id);

CREATE TABLE IF NOT EXISTS characteristics (
  id                  TEXT PRIMARY KEY,
  tender_id           TEXT NOT NULL,
  name                TEXT NOT NULL,
  value               TEXT,
  source              TEXT,
  comment             TEXT,
  derived_from_qa_id  TEXT,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE,
  FOREIGN KEY (derived_from_qa_id) REFERENCES qa_entries(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_characteristics_tender ON characteristics(tender_id);

CREATE TABLE IF NOT EXISTS analysis_runs (
  id           TEXT PRIMARY KEY,
  tender_id    TEXT NOT NULL,
  stage        INTEGER,                 -- 1..5 для kind='stage'; NULL для 'pipeline'
  kind         TEXT DEFAULT 'stage',    -- 'stage' (issues+signals) | 'pipeline' (draft/clusters/self)
  documents_revision_id TEXT,           -- ревизия набора документов тендера на момент прогона
  config_version        TEXT,           -- версия конфигурации анализа (варианты промтов + модель)
  started_at   TEXT NOT NULL,
  finished_at  TEXT,
  status       TEXT DEFAULT 'completed',-- 'running' | 'completed' | 'failed' | 'interrupted' | 'cancelled'
  summary      TEXT,
  superseded_at TEXT,                   -- NULL = актуальный; дата = архивный (неизменяемый) снимок
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_runs_tender_stage ON analysis_runs(tender_id, stage);
-- idx_runs_active (по kind/superseded_at) создаётся в migrate.js ПОСЛЕ ensureColumn:
-- на существующих БД CREATE TABLE IF NOT EXISTS не добавляет новые столбцы, а
-- schema.sql применяется РАНЬШЕ ensureColumn — индекс по новому столбцу упал бы.

-- Указатель актуального прогона для комбинации (тендер + scope + ревизия
-- документов + версия конфигурации). scope: 'stage:1'..'stage:5' | 'pipeline'.
-- Одна строка на (tender_id, scope) — чтения берут analysis_run_id отсюда.
CREATE TABLE IF NOT EXISTS analysis_active_runs (
  tender_id             TEXT NOT NULL,
  scope                 TEXT NOT NULL,   -- 'stage:1'..'stage:5' | 'pipeline'
  documents_revision_id TEXT,
  config_version        TEXT,
  analysis_run_id       TEXT NOT NULL,
  updated_at            TEXT NOT NULL,
  PRIMARY KEY (tender_id, scope),
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS issues (
  id                   TEXT PRIMARY KEY,
  tender_id            TEXT NOT NULL,
  analysis_run_id      TEXT,
  analysis_stage       INTEGER NOT NULL,
  source_document_id   TEXT,
  source_clause        TEXT,
  source_fragment      TEXT,
  paragraph_index      INTEGER,
  char_start           INTEGER,
  char_end             INTEGER,
  problem_type         TEXT,
  risk_category        TEXT,
  criticality          TEXT DEFAULT 'medium',
  price_impact         TEXT,
  schedule_impact      TEXT,
  basis                TEXT,
  suggested_action     TEXT,         -- 'comment' | 'replace' | 'delete' | 'remove_from_scope' | 'clarify' | 'limit_scope' | 'assumption'
  suggested_redaction  TEXT,
  review_comment       TEXT,
  confidence           REAL DEFAULT 0.6,
  section_path         TEXT,         -- путь заголовков из .md ТЗ (например: "1. Введение › 1.2 Объём работ")
  review_status        TEXT DEFAULT 'pending', -- 'pending' | 'accepted' | 'rejected' | 'edited'
  edited_redaction     TEXT,
  manually_edited      INTEGER DEFAULT 0,
  selected_for_export  INTEGER DEFAULT 1,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE,
  FOREIGN KEY (analysis_run_id) REFERENCES analysis_runs(id) ON DELETE CASCADE,
  FOREIGN KEY (source_document_id) REFERENCES documents(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_issues_tender_stage ON issues(tender_id, analysis_stage);

-- Слой сигналов (первый шаг новой архитектуры анализа:
--   входные данные -> signals -> единый анализатор -> critic -> clustering -> ...).
-- Параллельная запись: стадии 1..4 дополнительно эмитят сигналы рядом с issues,
-- НЕ меняя issue/review/export пайплайн. Источник — находки стадий.
CREATE TABLE IF NOT EXISTS analysis_signals (
  id                   TEXT PRIMARY KEY,
  tender_id            TEXT NOT NULL,
  analysis_run_id      TEXT,
  analysis_stage       INTEGER,
  signal_type          TEXT NOT NULL,    -- 'coverage' | 'decision' | 'condition' | 'risk'
  source_entity_type   TEXT,             -- что породило сигнал (пока 'issue')
  source_entity_id     TEXT,             -- id порождающей сущности (id issue)
  tz_clause            TEXT,             -- путь заголовков / пункт ТЗ
  source_fragment      TEXT,             -- дословный фрагмент ТЗ
  signal_payload_json  TEXT,             -- JSON с деталями находки
  weight               REAL DEFAULT 0.6, -- значимость 0..1 (берётся из confidence)
  created_at           TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE,
  FOREIGN KEY (analysis_run_id) REFERENCES analysis_runs(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_signals_tender_type ON analysis_signals(tender_id, signal_type);

-- Единый анализатор ТЗ (второй шаг новой архитектуры, поверх слоя signals).
-- Сводит совокупность signals одного места ТЗ в один draft_issue. Это
-- ПАРАЛЛЕЛЬНЫЙ слой — не заменяет issues/review/export.
CREATE TABLE IF NOT EXISTS draft_issues (
  id                      TEXT PRIMARY KEY,
  tender_id               TEXT NOT NULL,
  analysis_run_id         TEXT,             -- pipeline-прогон (снимок), которому принадлежит строка
  tz_clause               TEXT,             -- пункт/путь заголовков ТЗ
  source_fragment         TEXT,             -- дословный фрагмент ТЗ
  problem_type            TEXT,
  category                TEXT,             -- сводный signal_type(ы) группы
  basis                   TEXT,             -- краткое основание
  suggested_action        TEXT,
  suggested_redaction     TEXT,
  review_comment          TEXT,
  confidence              REAL DEFAULT 0.6,
  created_from_signal_ids TEXT,             -- JSON-массив id сигналов-источников
  paragraph_index         INTEGER,          -- для стабильного порядка/дебага
  -- Модель МАТЕРИАЛЬНОСТИ (services/review/materiality.js) — мнение АГЕНТОВ стадий,
  -- сведённое по сигналам группы. Авторитетный вердикт конвейера — в issue_reviews.
  impact_level            TEXT,             -- critical|high|medium|low|none (NULL = агент не оценил)
  evidence_level          TEXT,             -- strong|medium|weak
  verdict                 TEXT,             -- publish|verify|suppress
  impact_dimensions       TEXT,             -- JSON-массив: price|schedule|payment|contract|responsibility|scope
  publication_reason      TEXT,             -- почему публикуется (только для publish)
  suppression_reason      TEXT,             -- почему скрыто (только для suppress)
  required_action         TEXT,             -- amend_tz|exclude_scope|ask_customer|add_assumption|recalculate|none
  created_at              TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_draft_issues_tender ON draft_issues(tender_id);
-- idx_draft_issues_run (по analysis_run_id) создаётся в migrate.js после ensureColumn.

-- Слой critic (третий шаг новой архитектуры, поверх draft_issues).
-- Оценивает значимость каждого draft_issue ДЛЯ ГЕНПОДРЯДЧИКА и решает, показывать
-- ли его инженеру в основном потоке. Малозначимые НЕ удаляются — только
-- show_to_engineer=0 (скрыты по умолчанию). ПАРАЛЛЕЛЬНЫЙ слой.
-- draft_issue_id каскадно удаляется при пересборке draft_issues → critic
-- нужно перезапускать после unified/build.
CREATE TABLE IF NOT EXISTS issue_reviews (
  id                     TEXT PRIMARY KEY,
  tender_id              TEXT NOT NULL,      -- денормализация: выборки/идемпотентность по тендеру
  analysis_run_id        TEXT,               -- pipeline-прогон (снимок), которому принадлежит строка
  draft_issue_id         TEXT NOT NULL,
  business_impact        TEXT,               -- общий уровень: none|low|medium|high
  price_impact           TEXT,               -- расчёт / КП / приёмка-оплата / объём
  schedule_impact        TEXT,               -- сроки / график
  contract_impact        TEXT,               -- договор / существенные условия
  responsibility_impact  TEXT,               -- обязанности / ответственность / гарантия
  display_priority       TEXT,               -- ЛЕГАСИ-приоритет сортировки: critical|high|medium|low
  show_to_engineer       INTEGER DEFAULT 1,  -- 1=показывать (verdict='publish'), 0=скрыто по умолчанию
  critic_comment         TEXT,               -- человекочитаемое объяснение вердикта
  criteria_json          TEXT,               -- JSON сработавших критериев (прозрачность/дебаг)
  score                  REAL,               -- ЛЕГАСИ-балл (в нём есть criticality/confidence) — дебаг/тай-брейк
  -- Модель МАТЕРИАЛЬНОСТИ (services/review/materiality.js) — АВТОРИТЕТНОЕ решение
  -- о публикации. impact_level считается ТОЛЬКО по материальным критериям компании,
  -- evidence_level — по структурным фактам находки; criticality и confidence в них
  -- НЕ входят (иначе «модель уверена» снова подменяло бы «ГП дорого»).
  impact_level           TEXT,               -- critical|high|medium|low|none
  evidence_level         TEXT,               -- strong|medium|weak
  verdict                TEXT,               -- publish|verify|suppress (матрица impact × evidence)
  impact_dimensions      TEXT,               -- JSON-массив: price|schedule|payment|contract|responsibility|scope
  publication_reason     TEXT,               -- почему публикуется (только для publish)
  suppression_reason     TEXT,               -- почему скрыто (только для suppress)
  required_action        TEXT,               -- amend_tz|exclude_scope|ask_customer|add_assumption|recalculate|none
  -- PRECISION-КРИТИК (services/critic/precision/) — независимая проверка перед
  -- публикацией: уровень 1 детерминированные жёсткие фильтры, уровень 2 отдельная
  -- LLM-проверка спорных с установкой «искать основания НЕ показывать».
  critic_outcome         TEXT,               -- publish_critical|publish_working|hide_informational|reject_invalid; NULL = критик не решил (verdict='verify')
  critic_source          TEXT,               -- hard_filter|llm|escalation|unresolved (кто принял решение)
  critic_assessment      TEXT,               -- JSON: карта из 9 измерений + доводы против + сработавшее правило
  created_at             TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE,
  FOREIGN KEY (draft_issue_id) REFERENCES draft_issues(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_issue_reviews_tender ON issue_reviews(tender_id);
-- idx_issue_reviews_run (по analysis_run_id) создаётся в migrate.js после ensureColumn.

-- Слой clustering (четвёртый шаг новой архитектуры, поверх draft_issues + issue_reviews).
-- Сводит похожие замечания по ОДНОМУ месту ТЗ (tz_clause/фрагмент) И близкие по смыслу
-- (доминирующее измерение значимости + пересекающееся действие) в один кластер. Разные по
-- смыслу проблемы в одном пункте (открытый объём ≠ риск оплаты) остаются РАЗНЫМИ кластерами
-- — у каждого кластера свои cluster_items (исходные draft_issues), смысл не теряется.
CREATE TABLE IF NOT EXISTS issue_clusters (
  id                     TEXT PRIMARY KEY,
  tender_id              TEXT NOT NULL,
  analysis_run_id        TEXT,               -- pipeline-прогон (снимок), которому принадлежит кластер
  tz_clause              TEXT,               -- пункт/путь заголовков ТЗ (общий для кластера)
  cluster_title          TEXT,              -- краткий заголовок проблемы кластера
  merged_basis           TEXT,              -- объединённые основания разных стадий (по пунктам)
  merged_recommendation  TEXT,              -- объединённая рекомендация/действие
  overall_criticality    TEXT,              -- ЛЕГАСИ: critical|high|medium|low (макс. по элементам)
  show_to_engineer       INTEGER DEFAULT 1, -- 1=показывать (verdict='publish'), 0=скрыт
  final_problem_type     TEXT,              -- problem_type первичного (наиболее значимого) элемента
  -- Модель МАТЕРИАЛЬНОСТИ на уровне кластера (одно решение инженера = один вердикт).
  -- Свёртка по элементам: вердикт — сильнейший (publish > verify > suppress),
  -- влияние/доказательность — максимум, измерения — объединение.
  verdict                TEXT,              -- publish|verify|suppress
  overall_impact_level   TEXT,              -- critical|high|medium|low|none
  overall_evidence_level TEXT,              -- strong|medium|weak
  impact_dimensions      TEXT,              -- JSON-массив измерений влияния
  publication_reason     TEXT,              -- почему публикуется (от решающего элемента)
  suppression_reason     TEXT,              -- почему скрыто (от решающего элемента)
  required_action        TEXT,              -- что делать инженеру
  -- ПОВТОРЯЮЩЕЕСЯ ТРЕБОВАНИЕ (ярус 2, clustering/topicModel.js): одна обязанность
  -- ГП, встречающаяся в нескольких пунктах ТЗ, — ОДНО замечание с несколькими
  -- вхождениями, а не карточка на каждый абзац.
  occurrence_count       INTEGER,           -- число РАЗНЫХ мест ТЗ (item_count — число draft_issues)
  evidence_fragments     TEXT,              -- JSON: [{draft_issue_id, tz_clause, section, paragraph_index, fragment}]
  affected_sections      TEXT,              -- JSON-массив разделов ТЗ, затронутых требованием
  representative_fragment TEXT,             -- цитата первичного вхождения (её показывает карточка и ищет docx-экспорт)
  -- доп. прозрачность (сверх спеки):
  topic_key              TEXT,              -- тип риска|объект работ|последствие|действие (ось слияния яруса 2)
  work_object            TEXT,              -- предмет обязанности: cleaning|as_built_docs|temporary_utilities|…
  semantic_bucket        TEXT,              -- ключ смысловой группы (домен значимости + действие)
  cluster_key            TEXT,              -- стабильная сигнатура (placeKey::semanticBucket или topic:…) — основа детерминированного id
  item_count             INTEGER,           -- число draft_issues в кластере
  paragraph_index        INTEGER,           -- для стабильного порядка/дебага
  created_at             TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_issue_clusters_tender ON issue_clusters(tender_id);
-- idx_issue_clusters_run (по analysis_run_id) создаётся в migrate.js после ensureColumn.

CREATE TABLE IF NOT EXISTS issue_cluster_items (
  id                  TEXT PRIMARY KEY,
  cluster_id          TEXT NOT NULL,
  draft_issue_id      TEXT NOT NULL,
  item_role           TEXT,            -- primary|related (подпункт внутри кластера, смысл сохранён)
  created_at          TEXT NOT NULL,
  FOREIGN KEY (cluster_id) REFERENCES issue_clusters(id) ON DELETE CASCADE,
  FOREIGN KEY (draft_issue_id) REFERENCES draft_issues(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_cluster_items_cluster ON issue_cluster_items(cluster_id);

-- Слой self-analysis (пятый шаг новой архитектуры, поверх issue_clusters + issue_reviews + signals).
-- НОВАЯ роль Стадии 5 «Самоанализ ТЗ»: не второй хаотичный поток issues, а слой
-- QUALITY-CONTROL / COMPLETENESS-CHECK над уже собранным итогом. Проверяет не текст
-- ТЗ «с нуля», а готовые кластеры + исходный ТЗ и отвечает на 4 вопроса:
--   что могли пропустить · где кластеры слабые · где противоречие между кластерами ·
--   где усилить basis / review_comment / suggested_redaction.
-- НЕ дублирует Стадию 4 (та ищет типовые риски в тексте) — здесь оценка качества сборки.
-- ПАРАЛЛЕЛЬНЫЙ слой: не пишет в issues/review/export. cluster_id каскадно удаляется
-- при пересборке кластеров → self-analysis нужно перезапускать после clustering/build.
CREATE TABLE IF NOT EXISTS self_analysis_results (
  id                     TEXT PRIMARY KEY,
  tender_id              TEXT NOT NULL,
  analysis_run_id        TEXT,               -- pipeline-прогон (снимок), которому принадлежит замечание
  cluster_id             TEXT,               -- кластер-адресат замечания (NULL = про весь ТЗ / пропуск)
  finding_type           TEXT NOT NULL,      -- missed_coverage|weak_cluster|cluster_contradiction|needs_enrichment
  comment                TEXT,               -- что именно не так (человекочитаемо)
  suggested_improvement  TEXT,               -- как улучшить итог
  confidence             REAL DEFAULT 0.6,   -- уверенность 0..1
  -- доп. прозрачность (сверх минимума спеки):
  source                 TEXT,               -- heuristic|llm (чем порождено замечание)
  related_cluster_id     TEXT,               -- для cluster_contradiction — второй кластер пары
  created_at             TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE,
  FOREIGN KEY (cluster_id) REFERENCES issue_clusters(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_self_analysis_tender ON self_analysis_results(tender_id);
-- idx_self_analysis_run (по analysis_run_id) создаётся в migrate.js после ensureColumn.

-- Решение инженера по находке. Этап 6: основным адресатом стало issue_clusters
-- (cluster_id), issue_id оставлен как legacy/back-compat и больше НЕ NOT NULL.
-- ОДНО из (issue_id, cluster_id) заполнено. cluster_id — БЕЗ FK-constraint:
-- кластеры пересобираются (DELETE+INSERT), а решения должны переживать пересборку;
-- их id детерминирован (clusteringService.clusterId), поэтому ссылка стабильна.
CREATE TABLE IF NOT EXISTS review_decisions (
  id                  TEXT PRIMARY KEY,
  issue_id            TEXT,            -- legacy: находка стадии (nullable с этапа 6)
  cluster_id          TEXT,            -- new primary: issue_clusters.id (run-scoped, без FK)
  analysis_run_id     TEXT,            -- pipeline-прогон, к кластерам которого относится решение
  cluster_key         TEXT,            -- стабильная сигнатура кластера (для явного переноса между прогонами)
  decision            TEXT NOT NULL,   -- 'accept' | 'reject' | 'edit' | 'delete' | 'remove_from_scope'
  edited_redaction    TEXT,
  final_comment       TEXT,
  target_text         TEXT,            -- выбранная инженером ПОДЧАСТЬ фрагмента (NULL = весь фрагмент)
  decided_at          TEXT NOT NULL,
  FOREIGN KEY (issue_id) REFERENCES issues(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_decisions_issue ON review_decisions(issue_id);
-- idx_decisions_run (по analysis_run_id) создаётся в migrate.js после ensureColumn.
-- idx_decisions_cluster создаётся в migrate.js (ensureIndex) ПОСЛЕ ensureColumn(cluster_id),
-- т.к. на существующих БД CREATE TABLE IF NOT EXISTS не добавляет новый столбец.

CREATE TABLE IF NOT EXISTS tz_excluded_ranges (
  id                   TEXT PRIMARY KEY,
  tender_id            TEXT NOT NULL,
  source_document_id   TEXT,
  document_revision_id TEXT,             -- ревизия ТЗ, против которой посчитано исключение
  node_id              TEXT,             -- стабильный идентификатор узла (абзаца) в ТЗ
  source_text_hash     TEXT,             -- хэш исходного текста исключаемого фрагмента
  paragraph_index      INTEGER,
  char_start           INTEGER,
  char_end             INTEGER,
  after_stage          INTEGER NOT NULL,
  source_issue_id      TEXT,
  stale                INTEGER DEFAULT 0, -- 1 = исключение из другой ревизии, автоматически НЕ применяется
  needs_confirmation   INTEGER DEFAULT 0, -- 1 = требует подтверждения инженером после смены версии ТЗ
  created_at           TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE,
  FOREIGN KEY (source_document_id) REFERENCES documents(id) ON DELETE SET NULL,
  FOREIGN KEY (source_issue_id) REFERENCES issues(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_excluded_tender ON tz_excluded_ranges(tender_id);

CREATE TABLE IF NOT EXISTS tender_custom_risks (
  id          TEXT PRIMARY KEY,
  tender_id   TEXT NOT NULL,
  category    TEXT,
  risk_text   TEXT NOT NULL,
  triggers    TEXT,                  -- JSON-массив фраз
  criticality TEXT DEFAULT 'medium',
  created_at  TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tender_risk_state (
  tender_id   TEXT NOT NULL,
  risk_key    TEXT NOT NULL,        -- ключ из standardRisks.js
  applies     INTEGER,              -- 1=Да, 0=Нет, NULL=не указано (использовать auto-default)
  comment     TEXT,
  updated_at  TEXT NOT NULL,
  PRIMARY KEY (tender_id, risk_key),
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tender_setup_params (
  tender_id        TEXT PRIMARY KEY,
  contract_kind    TEXT,                 -- 'gen' | 'shell'
  escalation       TEXT,                 -- значение из PARAMS_SCHEMA[kind].escalation.options
  advance          TEXT,                 -- только для gen; для shell — NULL
  build_months     INTEGER,
  transfer_months  INTEGER,
  kp_date          TEXT,                 -- ISO date (YYYY-MM-DD)
  updated_at       TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS setup_locks (
  tender_id  TEXT NOT NULL,
  section    TEXT NOT NULL,        -- 'checklist' | 'conditions' | 'risks' | 'qa' | 'documents'
  locked_at  TEXT NOT NULL,
  PRIMARY KEY (tender_id, section),
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tender_stage_state (
  tender_id      TEXT PRIMARY KEY,
  current_stage  INTEGER DEFAULT 1,
  stage1_status  TEXT DEFAULT 'open',  -- 'open' | 'running' | 'reviewing' | 'finished'
  stage2_status  TEXT DEFAULT 'locked',
  stage3_status  TEXT DEFAULT 'locked',
  stage4_status  TEXT DEFAULT 'locked',
  stage5_status  TEXT DEFAULT 'locked',
  finished_at    TEXT,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

-- ─── Устойчивая очередь фоновых задач (analysis_jobs / analysis_tasks) ────────
-- Заменяет прежнее хранение фоновых прогонов в памяти процесса (Set/Map):
-- прогресс, отмена, повторы и восстановление после рестарта живут в БД, поэтому
-- переживают падение сервера и работают на нескольких процессах-воркерах.
--
-- analysis_jobs — ЗАДАНИЕ (запрос инженера: «прогнать стадию N», «пересобрать
-- конвейер»). Единица идемпотентности, отмены и отображения в UI.
CREATE TABLE IF NOT EXISTS analysis_jobs (
  id                    TEXT PRIMARY KEY,
  tender_id             TEXT NOT NULL,
  job_type              TEXT NOT NULL,             -- 'stage_analysis' | 'pipeline'
  scope_key             TEXT NOT NULL,             -- 'stage:1'..'stage:5' | 'pipeline'
  idempotency_key       TEXT NOT NULL,             -- повторный запуск того же прогона не создаёт дубль
  lock_key              TEXT NOT NULL,             -- ключ pg advisory-lock (bigint строкой)
  documents_revision_id TEXT,
  config_version        TEXT,
  analysis_run_id       TEXT,                      -- снимок анализа, который собирает задание
  status                TEXT NOT NULL DEFAULT 'queued', -- queued|running|completed|failed|cancelled|interrupted
  cancel_requested      INTEGER DEFAULT 0,
  payload_json          TEXT,
  result_json           TEXT,
  error                 TEXT,
  progress_total        INTEGER DEFAULT 0,
  progress_done         INTEGER DEFAULT 0,
  created_by            TEXT,
  created_at            TEXT NOT NULL,
  started_at            TEXT,
  finished_at           TEXT,
  updated_at            TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_jobs_tender ON analysis_jobs(tender_id, status);
CREATE INDEX IF NOT EXISTS idx_jobs_scope ON analysis_jobs(tender_id, scope_key, status);
-- Ключевой инвариант «без дублей»: на один ключ идемпотентности не может быть
-- двух ЖИВЫХ заданий. Гонку двух одновременных POST разрешает БД, а не приложение.
CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_idem_active
  ON analysis_jobs(idempotency_key) WHERE status IN ('queued', 'running');

-- analysis_tasks — ЗАДАЧА (единица работы воркера: одна стадия / один шаг
-- конвейера). Здесь живут аренда (lease) + heartbeat, попытки, checkpoint.
-- Задачи задания упорядочены по seq: следующая стартует после завершения
-- предыдущих (always_run=1 — финализатор, стартует и после сбоя шага).
CREATE TABLE IF NOT EXISTS analysis_tasks (
  id               TEXT PRIMARY KEY,
  job_id           TEXT NOT NULL,
  tender_id        TEXT NOT NULL,
  task_key         TEXT NOT NULL,            -- уникален внутри задания
  task_type        TEXT NOT NULL,            -- обработчик: 'stage_analysis' | 'pipeline_begin' | ...
  seq              INTEGER NOT NULL DEFAULT 0,
  always_run       INTEGER DEFAULT 0,        -- 1 = выполнить даже после сбоя предыдущих
  status           TEXT NOT NULL DEFAULT 'queued', -- queued|running|completed|failed|cancelled|interrupted|skipped
  attempts         INTEGER NOT NULL DEFAULT 0,
  max_attempts     INTEGER NOT NULL DEFAULT 3,
  priority         INTEGER NOT NULL DEFAULT 100,
  run_after        TEXT NOT NULL,            -- отложенный старт (backoff повторов)
  locked_by        TEXT,                     -- id воркера, взявшего задачу
  locked_at        TEXT,
  heartbeat_at     TEXT,
  lease_expires_at TEXT,                     -- аренда: истекла → воркер считается мёртвым
  progress_total   INTEGER DEFAULT 0,
  progress_done    INTEGER DEFAULT 0,
  checkpoint_json  TEXT,                     -- частичный результат: повтор продолжает с него
  payload_json     TEXT,
  result_json      TEXT,
  error            TEXT,
  created_at       TEXT NOT NULL,
  started_at       TEXT,
  finished_at      TEXT,
  updated_at       TEXT NOT NULL,
  UNIQUE (job_id, task_key),
  FOREIGN KEY (job_id) REFERENCES analysis_jobs(id) ON DELETE CASCADE,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_tasks_claim ON analysis_tasks(status, run_after, priority, seq);
CREATE INDEX IF NOT EXISTS idx_tasks_job ON analysis_tasks(job_id, seq);
CREATE INDEX IF NOT EXISTS idx_tasks_lease ON analysis_tasks(status, lease_expires_at);

-- Сегменты анализа ТЗ (иерархическая token-aware сегментация, shared/segmentation.js).
-- Большое ТЗ анализируется ПО ЧАСТЯМ, и у частей ДВЕ РАЗНЫЕ роли, которые
-- раньше жили в одной строке и мешали друг другу:
--   1) КЭШ результата части — чтобы повтор стадии не переспрашивал LLM про уже
--      посчитанное (перезаписываемый по своей природе);
--   2) ИСТОРИЯ ВЫПОЛНЕНИЯ части в конкретном прогоне — чтобы было видно, где
--      именно упал прогон №1 и что успел прогон №2 (неизменяемая по своей природе).
-- Пока это была одна строка на (тендер, стадия, номер части), повтор стадии
-- ЗАТИРАЛ историю предыдущего прогона: «какая часть уронила вчерашний анализ»
-- восстановить было нечем, а analysis_run_id показывал лишь последнего писателя.
--
-- analysis_segments — РОЛЬ 1: кэш, скоупленный РЕВИЗИЕЙ документов.
-- Ключ — (тендер, стадия, ревизия, номер части). Смена ревизии больше не
-- затирает кэш прошлой (возврат к прежней версии ТЗ снова переиспользует части).
-- Переиспользование дополнительно защищено input_hash (текст части + справочники)
-- и config_version (модель + вариант промта): не совпало — часть считается заново.
-- Строк на прогон здесь НЕТ и analysis_run_id здесь НЕТ — это кэш, а не история.
CREATE TABLE IF NOT EXISTS analysis_segments (
  id                    TEXT PRIMARY KEY,
  tender_id             TEXT NOT NULL,
  analysis_stage        INTEGER NOT NULL,
  document_revision_id  TEXT NOT NULL DEFAULT '', -- ревизия ТЗ, под которую нарезаны части
  config_version        TEXT,               -- версия конфигурации анализа (промты + модель)
  segment_index         INTEGER NOT NULL,   -- 0-based номер части
  segment_total         INTEGER,            -- всего частей в этой нарезке
  segment_key           TEXT,               -- детерминированный ключ содержимого части
  heading_path          TEXT,               -- заголовочный контекст части ('1. Общие › 1.2 Объём')
  first_block_index     INTEGER,            -- диапазон блоков ТЗ, покрытый частью
  last_block_index      INTEGER,
  chars                 INTEGER,
  tokens_estimate       INTEGER,
  input_hash            TEXT,               -- хэш user-сообщения (ТЗ-часть + справочники)
  status                TEXT NOT NULL DEFAULT 'pending', -- pending|completed (наличие результата)
  findings_count        INTEGER DEFAULT 0,
  findings_json         TEXT,               -- сырые находки части (переиспользуются при повторе)
  computed_run_id       TEXT,               -- прогон, ПОСЧИТАВШИЙ этот результат (справочно)
  created_at            TEXT NOT NULL,
  updated_at            TEXT NOT NULL,
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

-- Ключ кэша (ux_segments_cache) создаётся в migrate.js, а НЕ здесь: на
-- существующих БД у таблицы уже есть прежний UNIQUE (тендер, стадия, часть) без
-- ревизии, а CREATE TABLE IF NOT EXISTS его не меняет. Миграция снимает старый
-- ключ и ставит новый — одно место, одинаковое для новой и обновляемой базы.

CREATE INDEX IF NOT EXISTS idx_segments_stage ON analysis_segments(tender_id, analysis_stage, segment_index);
CREATE INDEX IF NOT EXISTS idx_segments_status ON analysis_segments(tender_id, status);

-- analysis_run_segments — РОЛЬ 2: НЕИЗМЕНЯЕМАЯ история выполнения частей.
-- Одна строка = одна часть ТЗ в ОДНОМ прогоне (UNIQUE (analysis_run_id,
-- segment_index)). Пишет её ТОЛЬКО прогон-владелец и ТОЛЬКО пока он running;
-- завершённый прогон свои строки не меняет — история двух последовательных
-- прогонов лежит рядом и не перетирается.
--   status: pending (не дошли) | running | completed | failed | interrupted | skipped
--   source: llm (часть реально посчитана) | cache (взята из analysis_segments)
--           | checkpoint (взята из чекпойнта задачи очереди)
-- Сами находки части здесь НЕ дублируются: результат прогона материализован в
-- issues (run-scoped), сырые находки части — в кэше. Здесь — факты выполнения:
-- что считалось, сколько попыток, чем кончилось, когда и с какой ошибкой.
CREATE TABLE IF NOT EXISTS analysis_run_segments (
  id                    TEXT PRIMARY KEY,
  analysis_run_id       TEXT NOT NULL,
  tender_id             TEXT NOT NULL,
  analysis_stage        INTEGER NOT NULL,
  segment_index         INTEGER NOT NULL,
  segment_total         INTEGER,
  segment_key           TEXT,
  heading_path          TEXT,
  first_block_index     INTEGER,
  last_block_index      INTEGER,
  chars                 INTEGER,
  tokens_estimate       INTEGER,
  document_revision_id  TEXT,
  config_version        TEXT,
  input_hash            TEXT,
  status                TEXT NOT NULL DEFAULT 'pending',
  source                TEXT,
  attempts              INTEGER NOT NULL DEFAULT 0,
  findings_count        INTEGER DEFAULT 0,
  error                 TEXT,
  created_at            TEXT NOT NULL,
  started_at            TEXT,
  finished_at           TEXT,
  updated_at            TEXT NOT NULL,
  UNIQUE (analysis_run_id, segment_index),
  FOREIGN KEY (tender_id) REFERENCES tenders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_run_segments_run ON analysis_run_segments(analysis_run_id, segment_index);
CREATE INDEX IF NOT EXISTS idx_run_segments_stage ON analysis_run_segments(tender_id, analysis_stage, analysis_run_id);

-- ============================================================================
-- Безопасность: тенанты (изоляция организаций) и журнал аудита.
-- ============================================================================

-- Тенант = организация. Тендер принадлежит ровно одному тенанту, всё остальное
-- (документы, находки, решения, выгрузки) наследует тенант через тендер.
CREATE TABLE IF NOT EXISTS tenants (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'active',  -- 'active' | 'suspended'
  created_at  TEXT NOT NULL
);

-- Журнал аудита: кто, что, над чем и чем кончилось. Пишется на КАЖДОЕ
-- обращение к защищённому маршруту: чтение, изменение, запуск анализа,
-- решение, выгрузка и любой отказ доступа (401/403/429).
-- Строки не изменяются и не удаляются приложением (только чистка по сроку
-- хранения — services/audit/auditService.purgeOlderThan).
CREATE TABLE IF NOT EXISTS audit_log (
  id             TEXT PRIMARY KEY,
  ts             TEXT NOT NULL,
  request_id     TEXT,
  tenant_id      TEXT,
  actor_sub      TEXT,              -- subject токена (sub)
  actor_email    TEXT,
  actor_roles    TEXT,              -- роли через запятую на момент действия
  auth_method    TEXT,              -- 'token' | 'dev-bypass'
  action         TEXT NOT NULL,     -- 'stage.run', 'review.cluster.decide', 'export.docx', ...
  category       TEXT NOT NULL,     -- read|write|analysis|decision|export|admin|auth
  outcome        TEXT NOT NULL,     -- allowed|denied|error
  resource_type  TEXT,
  resource_id    TEXT,
  tender_id      TEXT,
  method         TEXT,
  path           TEXT,
  status         INTEGER,
  duration_ms    INTEGER,
  ip             TEXT,
  user_agent     TEXT,
  reason         TEXT,              -- код и причина отказа (без секретов)
  meta           TEXT               -- JSON: хэш файла, подпись антивируса и т.п.
);

CREATE INDEX IF NOT EXISTS idx_audit_tenant_ts ON audit_log(tenant_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_audit_tender_ts ON audit_log(tender_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_audit_actor_ts  ON audit_log(actor_sub, ts DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action_ts ON audit_log(action, ts DESC);
